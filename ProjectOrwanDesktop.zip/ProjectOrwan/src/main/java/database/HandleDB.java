/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package database;

import com.mycompany.projectorwan.model.OrwanInput;
import com.mycompany.projectorwan.model.OrwanOutput;
import com.mycompany.projectorwan.model.User;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author kassi
 */
public class HandleDB {
     public HandleDB() {
    }

    // connection avec la base de donne
    public static Statement connectToDB() throws ClassNotFoundException, SQLException {

        Connection connect = null;
        Statement statement = null;
        String url = "jdbc:mysql://localhost:3306/orwan?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
        String user = "root";
        String password = "IKRAM.hiba2004";

        try {
            // Definer notre driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Initializer la connection
            connect = DriverManager.getConnection(url, user, password);
            // statements
            statement = connect.createStatement();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(HandleDB.class.getName()).log(Level.SEVERE, null, ex);
        }

        return statement;
    }
    
    
    public static List<User> getUsers() {
        List<User> users = new ArrayList<>();

        try {
            Statement st = connectToDB();
            String sql = "select * from user";
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                String username = rs.getString("username");
                String password = rs.getString("password");
                String role = rs.getString("role");

                User user = new User(username, password, role);
                users.add(user);
            }

        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(HandleDB.class.getName()).log(Level.SEVERE, null, ex);
        }

        return users;
    }
    
    
     public static void addInput(OrwanInput input) {
        try {
            Statement st = connectToDB();
            String requette = "INSERT INTO `OrwanInput`(`Cas`, `He`, `Hs`,`Te`,`Ts`,`Diam_WR`,`WRyoung`,`offset`,`muIni`,`forceAPply`,`GForward`) "
                    + "VALUES ('" + input.getCas() + "','" + input.getHe() + "','" + input.getHs() + "','" + input.getTe()+  "','"
                    + input.getTs() + "','" + input.getDiamWR() + "','" + input.getWRyoung() + "','" + input.getOffset() + "','" 
                    + input.getMuIni() + "','" + input.getForce() + "','" + input.getG()  + "')";
            st.execute(requette);
            System.out.println("Input added");
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(HandleDB.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
     
    public static void removeInput() {
        try {
            Statement st = connectToDB();
            String requette = "DELETE FROM `OrwanInput`";
            st.execute(requette);
            System.out.println("Table deleted");
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(HandleDB.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
    public static void removeOutput() {
        try {
            Statement st = connectToDB();
            String requette = "DELETE FROM `OrwanOutput`";
            st.execute(requette);
            System.out.println("Table deleted");
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(HandleDB.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
     
     
    public static void addOutput(OrwanOutput input) {
        try {
            Statement st = connectToDB();
            String requette = "INSERT INTO `OrwanOutput`(`Casee`, `Errors`, `OffsetYield`,`Friction`,`RollingTorque`,`SigmaMoy`,`Sigma_Ini`,`Sigma_Out`,`Sigma_Max`,`forceError`,`slipError`,`hasConvergeed`) "
                    + "VALUES ('" + input.getCase() + "','" + input.getErrors() + "','" + input.getOffsetYield() + "','" + input.getFriction()+  "','"
                    + input.getRolling_Torque() + "','" + input.getSigma_Moy() + "','" + input.getSigma_In() + "','" + input.getSigma_Out() + "','" 
                    + input.getSigma_Max() + "','" + input.getForce_Erro() + "','" + input.getSlip_Error() +  "','" + input.getHas_Converged()+ "')";
            st.execute(requette);
            System.out.println("Output added");
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(HandleDB.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
    
    
    public static void createUser(User user) {
        try {
            Statement st = connectToDB();
            String requette = "INSERT INTO `user`(`password`, `role`, `username`) "
                    + "VALUES ('" + user.getPassword() + "','" + user.getRole() + "','" + user.getUsername() +"')";
            st.execute(requette);
            System.out.println("user added");
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(HandleDB.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
    
    public static void deleteUser(String username) {
        try {
            Statement st = connectToDB();
            String requete = "DELETE FROM `user` WHERE `username` = '" + username + "'";
            st.execute(requete);
            System.out.println("user deleted");
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(HandleDB.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
    
    public static void updateUser(User user) {
        try {
            Statement st = connectToDB();
            String requete = "UPDATE `user` SET `role` = '" + user.getRole() + "', `password` = '"+ user.getPassword() + "' WHERE `username` = '" + user.getUsername() + "'";
            st.execute(requete);
            System.out.println("user deleted");
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(HandleDB.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
