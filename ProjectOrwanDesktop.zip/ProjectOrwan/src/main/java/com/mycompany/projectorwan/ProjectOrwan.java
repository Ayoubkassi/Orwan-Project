/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projectorwan;

/**
 *
 * @author kassi
 */
public class ProjectOrwan {

    public static void main(String[] args) {
        
    }
}
