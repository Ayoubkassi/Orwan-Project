package com.mycompany.projectorwan.view;


import static com.mycompany.projectorwan.controller.OrwanConroller.getOrwanOutput;
import com.mycompany.projectorwan.model.OrwanOutput;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class Sigma {
    public static void main(String[] args) throws IOException {
//        double[] xData = {1.0, 2.0, 3.0, 4.0, 5.0};
//        double[] yData = {10.0, 20.0, 15.0, 25.0, 30.0};
          List<OrwanOutput> outputs = getOrwanOutput("/home/kassi/Desktop/ProjectOrwan/Data/output.txt");
          int size = outputs.size();
          double[] xData = new double[size];
          double[] yData = new double[size];
          for (int i = 0; i <30; i++) {
                xData[i] = (double)i;
           }
          int i = 0;
          for(OrwanOutput output : outputs){
              yData[i++] = output.getSigma_Moy();
          }
          
        
        // Create a dataset with the x and y data
        XYDataset dataset = createDataset(xData, yData);
        
        // Create a chart using the dataset
        JFreeChart chart = createChart(dataset);
        
        // Create a panel to display the chart
        JPanel chartPanel = new ChartPanel(chart);
        
        // Create a frame to hold the panel
        JFrame frame = new JFrame("Graph Demo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(chartPanel);
        frame.pack();
        frame.setVisible(true);
    }
    
    private static XYDataset createDataset(double[] xData, double[] yData) {
        XYSeries series = new XYSeries("Data");
        
        for (int i = 0; i < xData.length; i++) {
            series.add(xData[i], yData[i]);
        }
        
        XYSeriesCollection dataset = new XYSeriesCollection();
        dataset.addSeries(series);
        
        return dataset;
    }
    
    private static JFreeChart createChart(XYDataset dataset) {
        JFreeChart chart = ChartFactory.createXYLineChart(
            "Sigma Graph",
            "XTime",
            "Sigma",
            dataset
        );
        
        return chart;
    }

    void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
