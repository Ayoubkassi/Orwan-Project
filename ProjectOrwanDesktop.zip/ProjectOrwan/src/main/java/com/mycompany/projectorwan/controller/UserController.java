/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projectorwan.controller;

import com.mycompany.projectorwan.model.User;
import static database.HandleDB.getUsers;
import java.util.List;

/**
 *
 * @author kassi
 */
public class UserController {
    
    
    public static String login(String username , String password){
        List<User> users = getUsers();
        for(User user : users){
            if(user.getUsername().equals(username) && user.getPassword().equals(password)){
                return user.getRole();
            }
        }
        
        return "";
    }
}
