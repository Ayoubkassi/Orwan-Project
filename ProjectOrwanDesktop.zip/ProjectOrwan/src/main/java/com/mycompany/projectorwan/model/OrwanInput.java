/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projectorwan.model;

/**
 *
 * @author kassi
 */
public class OrwanInput {
    
    private Integer cas;
    private double he;
    private double hs;
    private double te;
    private double ts;
    private double diamWR;
    private double WRyoung;
    private double offset;
    private double muIni;
    private double Force;
    private double G;

    public Integer getCas() {
        return cas;
    }

    public void setCas(Integer cas) {
        this.cas = cas;
    }

    public double getHe() {
        return he;
    }

    public void setHe(double he) {
        this.he = he;
    }

    public double getHs() {
        return hs;
    }

    public void setHs(double hs) {
        this.hs = hs;
    }

    public double getTe() {
        return te;
    }

    public void setTe(double te) {
        this.te = te;
    }

    public double getTs() {
        return ts;
    }

    public void setTs(double ts) {
        this.ts = ts;
    }

    public double getDiamWR() {
        return diamWR;
    }

    public void setDiamWR(double diamWR) {
        this.diamWR = diamWR;
    }

    public double getWRyoung() {
        return WRyoung;
    }

    public void setWRyoung(double WRyoung) {
        this.WRyoung = WRyoung;
    }

    public double getOffset() {
        return offset;
    }

    public void setOffset(double offset) {
        this.offset = offset;
    }

    public double getMuIni() {
        return muIni;
    }

    public void setMuIni(double muIni) {
        this.muIni = muIni;
    }

    public double getForce() {
        return Force;
    }

    public void setForce(double Force) {
        this.Force = Force;
    }

    public double getG() {
        return G;
    }

    public void setG(double G) {
        this.G = G;
    }

    public OrwanInput(Integer cas, double he, double hs, double te, double ts, double diamWR, double WRyoung, double offset, double muIni, double Force, double G) {
                   System.out.println("created");
        this.cas = cas;
        this.he = he;
        this.hs = hs;
        this.te = te;
        this.ts = ts;
        this.diamWR = diamWR;
        this.WRyoung = WRyoung;
        this.offset = offset;
        this.muIni = muIni;
        this.Force = Force;
        this.G = G;
    }

    public OrwanInput() {
    }

    @Override
    public String toString() {
        return "OrwanInput{" + "cas=" + cas + ", he=" + he + ", hs=" + hs + ", te=" + te + ", ts=" + ts + ", diamWR=" + diamWR + ", WRyoung=" + WRyoung + ", offset=" + offset + ", muIni=" + muIni + ", Force=" + Force + ", G=" + G + '}';
    }
    
    
    
    
}
