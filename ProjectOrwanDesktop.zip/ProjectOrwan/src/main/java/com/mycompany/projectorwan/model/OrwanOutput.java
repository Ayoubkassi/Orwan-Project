/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projectorwan.model;

/**
 *
 * @author kassi
 */
public class OrwanOutput {
    private int Case;
    private String Errors ;
    private double OffsetYield;
    private double Friction;
    private double Rolling_Torque;
    private double sigma_Moy;
    private double sigma_In;
    private double sigma_Out;
    private double sigma_Max ;
    private double Force_Erro ;
    private double Slip_Error;
    private String Has_Converged ;

    public int getCase() {
        return Case;
    }

    public void setCase(int Case) {
        this.Case = Case;
    }

    public String getErrors() {
        return Errors;
    }

    public void setErrors(String Errors) {
        this.Errors = Errors;
    }

    public double getOffsetYield() {
        return OffsetYield;
    }

    public void setOffsetYield(double OffsetYield) {
        this.OffsetYield = OffsetYield;
    }

    public double getFriction() {
        return Friction;
    }

    public void setFriction(double Friction) {
        this.Friction = Friction;
    }

    public double getRolling_Torque() {
        return Rolling_Torque;
    }

    public void setRolling_Torque(double Rolling_Torque) {
        this.Rolling_Torque = Rolling_Torque;
    }

    public double getSigma_Moy() {
        return sigma_Moy;
    }

    public void setSigma_Moy(double sigma_Moy) {
        this.sigma_Moy = sigma_Moy;
    }

    public double getSigma_In() {
        return sigma_In;
    }

    public void setSigma_In(double sigma_In) {
        this.sigma_In = sigma_In;
    }

    public double getSigma_Out() {
        return sigma_Out;
    }

    public void setSigma_Out(double sigma_Out) {
        this.sigma_Out = sigma_Out;
    }

    public double getSigma_Max() {
        return sigma_Max;
    }

    public void setSigma_Max(double sigma_Max) {
        this.sigma_Max = sigma_Max;
    }

    public double getForce_Erro() {
        return Force_Erro;
    }

    public void setForce_Erro(double Force_Erro) {
        this.Force_Erro = Force_Erro;
    }

    public double getSlip_Error() {
        return Slip_Error;
    }

    public void setSlip_Error(double Slip_Error) {
        this.Slip_Error = Slip_Error;
    }

    public String getHas_Converged() {
        return Has_Converged;
    }

    public void setHas_Converged(String Has_Converged) {
        this.Has_Converged = Has_Converged;
    }

    public OrwanOutput(int Case, String Errors, double OffsetYield, double Friction, double Rolling_Torque, double sigma_Moy, double sigma_In, double sigma_Out, double sigma_Max, double Force_Erro, double Slip_Error, String Has_Converged) {
        this.Case = Case;
        this.Errors = Errors;
        this.OffsetYield = OffsetYield;
        this.Friction = Friction;
        this.Rolling_Torque = Rolling_Torque;
        this.sigma_Moy = sigma_Moy;
        this.sigma_In = sigma_In;
        this.sigma_Out = sigma_Out;
        this.sigma_Max = sigma_Max;
        this.Force_Erro = Force_Erro;
        this.Slip_Error = Slip_Error;
        this.Has_Converged = Has_Converged;
    }

    public OrwanOutput() {
    }
    
    
    
}
