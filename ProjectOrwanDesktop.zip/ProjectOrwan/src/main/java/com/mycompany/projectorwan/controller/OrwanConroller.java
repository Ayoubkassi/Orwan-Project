/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projectorwan.controller;

import com.mycompany.projectorwan.model.OrwanInput;
import com.mycompany.projectorwan.model.OrwanOutput;
import static database.HandleDB.addInput;
import static database.HandleDB.addOutput;
import static database.HandleDB.removeInput;
import static database.HandleDB.removeOutput;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author kassi
 */
public class OrwanConroller {
    
    
    
    public static List<OrwanInput> getOrwanInput(String path) throws FileNotFoundException, IOException{
        path = "/home/kassi/Desktop/ProjectOrwan/Data/inv_cst.txt";
        List<OrwanInput> orwanInputs = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new FileReader(path));
        //delete allrecords
        removeInput();
        OrwanInput current;
        String line = reader.readLine();
        int itter = 0;
        while (line != null) {
            if(itter == 0){
                itter++;
                line = reader.readLine();
                continue;
            }
            String[] values = line.split("\t");
            //System.out.println(values[0]);
//            current = new OrwanInput(Integer.valueOf(values[0]),Double.valueOf(values[1]),Double.valueOf(values[2]),Double.valueOf(values[3]),
//                    Double.valueOf(values[4]),Double.valueOf(values[5]),Double.valueOf(values[6]),Double.valueOf(values[7]),
//                    Double.valueOf(values[8]),Double.valueOf(values[9]),Double.valueOf(values[10]));
//            orwanInputs.add(current);
             int cas = Integer.valueOf(values[0].trim());
             double he = Double.valueOf(values[1].trim());
             double hs = Double.valueOf(values[2].trim());
             double te = Double.valueOf(values[3].trim());
             double ts = Double.valueOf(values[4].trim());
             double diam = Double.valueOf(values[5].trim());
             double wryoung = Double.valueOf(values[6].trim());
             double offset = Double.valueOf(values[7].trim());
             double muni = Double.valueOf(values[8].trim());
             double force = Double.valueOf(values[9].trim());
             double g = Double.valueOf(values[10].trim());
             
             current = new OrwanInput(cas,he,hs,te,ts,diam,wryoung,offset,muni,force,g);
             //System.out.println(current.toString());
             
            addInput(current);
            orwanInputs.add(current);
            line = reader.readLine();
        }

        reader.close();
        
        return orwanInputs;
    }
    
    
    public static List<OrwanOutput> getOrwanOutput(String path) throws FileNotFoundException, IOException{
        List<OrwanOutput> orwanOutputs = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new FileReader(path));
        OrwanOutput current ;
        removeOutput();
        String line = reader.readLine();
        int itter = 0;
        while (line != null) {
            if(itter == 0){
                itter++;
                line = reader.readLine();
                continue;
            }
            String[] values = line.split("\t");
            //System.out.println(values[0]);
//            current = new OrwanInput(Integer.valueOf(values[0]),Double.valueOf(values[1]),Double.valueOf(values[2]),Double.valueOf(values[3]),
//                    Double.valueOf(values[4]),Double.valueOf(values[5]),Double.valueOf(values[6]),Double.valueOf(values[7]),
//                    Double.valueOf(values[8]),Double.valueOf(values[9]),Double.valueOf(values[10]));
//            orwanInputs.add(current);
             int cas = Integer.valueOf(values[0].trim());
             double offset = Double.valueOf(values[2].trim());
             double friction = Double.valueOf(values[3].trim());
             double rolling = Double.valueOf(values[4].trim());
             double moy = Double.valueOf(values[5].trim());
             double ini = Double.valueOf(values[6].trim());
             double out = Double.valueOf(values[7].trim());
             double sigmax = Double.valueOf(values[8].trim());
             double force = Double.valueOf(values[9].trim());
             double slip = Double.valueOf(values[10].trim());
             
             current = new OrwanOutput(cas,values[1].trim(),offset,friction,rolling,moy,ini,out,sigmax,force,slip,values[11].trim());
             //System.out.println(current.toString());
             orwanOutputs.add(current);
            addOutput(current);
            line = reader.readLine();
        }

        reader.close();
        
        return orwanOutputs;
    }
    
    
    public static void main(String[] args) throws IOException {
        //List<OrwanInput> res1 = getOrwanInput("/home/kassi/Desktop/ProjectOrwan/Data/inv_cst.txt");
        //List<OrwanOutput> res2 = getOrwanOutput("/home/kassi/Desktop/ProjectOrwan/Data/output.txt");

        
        
    }
}
